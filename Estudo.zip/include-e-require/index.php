 <?php 
 include 'header.php'// ou include_once
 ?>

 <?php echo "Olá pessoal";?>

 <?php
 require 'footer.php';//ou require_once
 ?>
    