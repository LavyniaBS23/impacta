<html>
    <head>
        <title>Include e require</title>
        <meta charset = "utf-8">
    </head>
    <body>