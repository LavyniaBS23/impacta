<?php
/*$nome = $_POST['nome'];
$email = $_POST['email'];

echo "Seu nome é $nome e seu email é $email.";

var_dump($_POST);*/

/*$nome = $_GET['nome'];
$email = $_GET['email'];

echo "Seu nome é $nome e seu email é $email.";
var_dump($_GET);*/
echo $_GET['idade']."<br>".$_GET['sobrenome'];
var_dump($_GET);