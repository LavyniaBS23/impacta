<?php
echo 10 + 10;
//exponenciação **
echo "<br>";
echo 3**5;

$a = 10;
$b = 20;
$c = 30;
$d = 3;
$e = 21;
$adicao = $a + $b + $c;
echo "<br>" . $adicao;

$subtracao = $c - $a;
echo "<br>" . $subtracao;
echo "<hr>";

$multiplicacao = $d * $a;
echo "<br>" . $multiplicacao;
echo "<hr>";

$modulo = $e % $d;
echo $modulo;
echo "<hr>";
$expo = $a ** $d;
echo $expo;
