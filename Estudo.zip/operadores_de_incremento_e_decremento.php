<?php
$valor = 20;

// pré-incremento
//echo ++$valor . "<br>";

// pos-incremento

/*echo $valor++;
echo "<br>";
echo $valor;*/

///pre-decremento

echo --$valor. "<br>";

//pós-decremento
echo $valor--;

echo "<br>";
echo $valor;