<?php

$a = 10;
$b = 5;
//$a = $a + $b;

//echo $a;

$a += $b;
$a %= $b;
echo $a;
